import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().min(1, "emailRequired").email("invalidEmail"),
  password: z.string().min(1, "passwordRequired"),
});

export type LoginFormValues = z.infer<typeof loginSchema>;
